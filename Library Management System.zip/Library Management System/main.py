from database import Database

def print_menu():
    print("\n--- Library Management System ---")
    print("1. Add Book")
    print("2. Register User")
    print("3. Issue Book")
    print("4. Return Book")
    print("5. Search Books")
    print("6. View Available Books")
    print("7. View All Books")
    print("8. View All Users")
    print("9. Exit")

def get_positive_integer(prompt):
    while True:
        try:
            value = int(input(prompt))
            if value > 0:
                return value
            else:
                print("Please enter a positive number.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def main():
    db = Database()

    while True:
        print_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            title = input("Enter title: ")
            author = input("Enter author: ")
            isbn = input("Enter ISBN: ")
            quantity = get_positive_integer("Enter quantity: ")
            if db.add_book(title, author, isbn, quantity):
                print("Book added successfully.")
            else:
                print("Book with this ISBN already exists.")

        elif choice == '2':
            name = input("Enter user name: ")
            user_id = input("Enter user ID: ")
            if db.register_user(name, user_id):
                print("User registered successfully.")
            else:
                print("User with this ID already exists.")

        elif choice == '3':
            isbn = input("Enter book ISBN to issue: ")
            user_id = input("Enter user ID: ")
            book = db.get_book_by_isbn(isbn)
            user = db.get_user_by_uid(user_id)
            if book and user:
                if db.issue_book(book[0], user[0]):
                    print("Book issued successfully.")
                else:
                    print("Book is not available.")
            else:
                print("Invalid book ISBN or user ID.")

        elif choice == '4':
            isbn = input("Enter book ISBN to return: ")
            user_id = input("Enter user ID: ")
            book = db.get_book_by_isbn(isbn)
            user = db.get_user_by_uid(user_id)
            if book and user:
                if db.return_book(book[0], user[0]):
                    print("Book returned successfully.")
                else:
                    print("This book was not issued to this user or already returned.")
            else:
                print("Invalid book ISBN or user ID.")

        elif choice == '5':
            query = input("Enter title or author to search: ")
            books = db.search_books(query)
            if books:
                for book in books:
                    print(f"ID: {book[0]}, Title: {book[1]}, Author: {book[2]}, ISBN: {book[3]}, Quantity: {book[4]}, Available: {book[5]}")
            else:
                print("No books found.")

        elif choice == '6':
            books = db.get_available_books()
            if books:
                for book in books:
                    print(f"ID: {book[0]}, Title: {book[1]}, Author: {book[2]}, ISBN: {book[3]}, Quantity: {book[4]}, Available: {book[5]}")
            else:
                print("No available books.")

        elif choice == '7':
            books = db.get_all_books()
            if books:
                for book in books:
                    print(f"ID: {book[0]}, Title: {book[1]}, Author: {book[2]}, ISBN: {book[3]}, Quantity: {book[4]}, Available: {book[5]}")
            else:
                print("No books in the library.")

        elif choice == '8':
            users = db.get_all_users()
            if users:
                for user in users:
                    print(f"ID: {user[0]}, Name: {user[1]}, User ID: {user[2]}")
            else:
                print("No users registered.")

        elif choice == '9':
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == '__main__':
    main()