import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_name='library.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                isbn TEXT UNIQUE NOT NULL,
                quantity INTEGER NOT NULL,
                available INTEGER NOT NULL
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                user_id TEXT UNIQUE NOT NULL
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS issued_books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER,
                user_id INTEGER,
                issue_date TEXT NOT NULL,
                return_date TEXT,
                FOREIGN KEY (book_id) REFERENCES books(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        self.conn.commit()

    def add_book(self, title, author, isbn, quantity):
        try:
            self.cursor.execute('''
                INSERT INTO books (title, author, isbn, quantity, available)
                VALUES (?, ?, ?, ?, ?)
            ''', (title, author, isbn, quantity, quantity))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def register_user(self, name, user_id):
        try:
            self.cursor.execute('''
                INSERT INTO users (name, user_id) VALUES (?, ?)
            ''', (name, user_id))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def issue_book(self, book_id, user_id):
        self.cursor.execute('SELECT available FROM books WHERE id = ?', (book_id,))
        available = self.cursor.fetchone()
        if available and available[0] > 0:
            self.cursor.execute('UPDATE books SET available = available - 1 WHERE id = ?', (book_id,))
            issue_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.cursor.execute('''
                INSERT INTO issued_books (book_id, user_id, issue_date) VALUES (?, ?, ?)
            ''', (book_id, user_id, issue_date))
            self.conn.commit()
            return True
        return False

    def return_book(self, book_id, user_id):
        self.cursor.execute('''
            SELECT id FROM issued_books 
            WHERE book_id = ? AND user_id = ? AND return_date IS NULL
        ''', (book_id, user_id))
        issue_record = self.cursor.fetchone()
        if issue_record:
            self.cursor.execute('UPDATE books SET available = available + 1 WHERE id = ?', (book_id,))
            return_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.cursor.execute('UPDATE issued_books SET return_date = ? WHERE id = ?', (return_date, issue_record[0]))
            self.conn.commit()
            return True
        return False

    def search_books(self, query):
        self.cursor.execute('''
            SELECT id, title, author, isbn, quantity, available FROM books
            WHERE title LIKE ? OR author LIKE ?
        ''', (f'%{query}%', f'%{query}%'))
        return self.cursor.fetchall()

    def get_available_books(self):
        self.cursor.execute('SELECT id, title, author, isbn, quantity, available FROM books WHERE available > 0')
        return self.cursor.fetchall()

    def get_all_books(self):
        self.cursor.execute('SELECT id, title, author, isbn, quantity, available FROM books')
        return self.cursor.fetchall()

    def get_all_users(self):
        self.cursor.execute('SELECT id, name, user_id FROM users')
        return self.cursor.fetchall()

    def get_user_by_uid(self, user_id):
        self.cursor.execute('SELECT id FROM users WHERE user_id = ?', (user_id,))
        return self.cursor.fetchone()

    def get_book_by_isbn(self, isbn):
        self.cursor.execute('SELECT id FROM books WHERE isbn = ?', (isbn,))
        return self.cursor.fetchone()

    def __del__(self):
        self.conn.close()