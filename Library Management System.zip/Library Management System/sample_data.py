from database import Database

def populate_sample_data():
    db = Database()

    # Sample books
    books = [
        ('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 5, 5),
        ('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 3, 3),
        ('1984', 'George Orwell', '9780451524935', 7, 7),
        ('The Catcher in the Rye', 'J.D. Salinger', '9780316769488', 4, 4)
    ]

    for book in books:
        db.cursor.execute('''
            INSERT OR IGNORE INTO books (title, author, isbn, quantity, available)
            VALUES (?, ?, ?, ?, ?)
        ''', book)

    # Sample users
    users = [
        ('Alice Smith', 'ALICE001'),
        ('Bob Johnson', 'BOB002')
    ]

    for user in users:
        db.cursor.execute('''
            INSERT OR IGNORE INTO users (name, user_id) VALUES (?, ?)
        ''', user)

    db.conn.commit()
    print("Sample data populated.")

if __name__ == '__main__':
    populate_sample_data()