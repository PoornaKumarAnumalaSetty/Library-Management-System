# Library Management System

This is a simple console-based Library Management System implemented in Python using SQLite for data storage.

## Features

- Add new books
- Register new users
- Issue books to users
- Return books
- Search for books by title or author
- View a list of available books
- Persistent data storage with SQLite

## Setup and Running

1.  **Prerequisites**:
    *   Python 3.x

2.  **Installation**:
    *   No external libraries are needed besides the standard Python library.

3.  **Populate Sample Data (Optional)**:
    *   To populate the database with some initial sample data, run the `sample_data.py` script:
        ```bash
        python sample_data.py
        ```

4.  **Run the Application**:
    *   To start the Library Management System, run the `main.py` script:
        ```bash
        python main.py
        ```

5.  **Using the Application**:
    *   Once the application is running, you will see a menu with options. Enter the number corresponding to the action you want to perform.